import os
import requests

TOKEN = os.getenv("TEMPORARY_ACCESS_TOKEN")
PHONE_ID = os.getenv("PHONE_NUMBER_ID")

url = "https://graph.facebook.com/v17.0/" + PHONE_ID + "?fields=throughput"
headers = {"Authorization": "Bearer " + TOKEN}

request = requests.get(url, headers=headers)

print(request.status_code)
print(request.json())
