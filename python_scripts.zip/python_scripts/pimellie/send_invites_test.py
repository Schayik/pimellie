import os
import requests

TOKEN = os.getenv("TEMPORARY_ACCESS_TOKEN")
PHONE_ID = os.getenv("PHONE_NUMBER_ID")
ACCOUNT_ID = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID")

url = "https://graph.facebook.com/v17.0/" + PHONE_ID + "/messages"

headers = {
    "Authorization": "Bearer " + TOKEN,
    "Content-Type": "application/json",
}

phone_number = "+31683488976"
test_phone_number = "164031540124222"

hello_world_data = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "template",
    "template": {"name": "hello_world", "language": {"code": "en_US"}},
}

rsvp_data = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "template",
    "template": {
        "name": "rsvp",
        "language": {"code": "nl"},
        "components": [
            {
                "type": "body",
                "parameters": [{"type": "text", "text": "Floor & Bart"}],
            },
        ],
    },
    # "type": "image",
    # "image": {"link": "https://ibb.co/6yDKzZD"},
    # "components": [
    #     {
    #         "type": "body",
    #         "parameters": [{"type": "text", "text": "Floor & Bart"}],
    #     }
    # ],
}

invitation_data = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "template",
    "template": {
        "name": "invitation",
        "language": {"code": "en_GB"},
        "components": [
            {
                "type": "body",
                "parameters": [{"type": "text", "text": "Floor & Bart"}],
            }
        ],
    },
}

flow_data = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "template",
    "template": {
        "name": "flow",
        "language": {"code": "en_GB"},
        "components": [
            {
                "type": "body",
                "parameters": [{"type": "text", "text": "Floor & Bart"}],
            },
            {
                "type": "BUTTONS",
                "buttons": [
                    {
                        "type": "FLOW",
                        "text": "Open flow!",
                        "flow_id": "<flow-id>",
                        "navigate_screen": "Flows Json screen name",
                        "flow_action": "navigate",
                    }
                ],
            },
        ],
    },
}

# "type": "flow",
# "flow_message_version": 3,
# "flow_token": ACCOUNT_ID,
# "flow_id": "882012090050803",
# "flow_cta": "RSVP",

interactive = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "interactive",
    "interactive": {
        "type": "flow",
        "body": {
            "text": "RSVP",
        },
        "action": {
            "name": "flow",
            "parameters": {
                "flow_message_version": 3,
                "flow_token": ACCOUNT_ID,
                "flow_id": "882012090050803",
                "flow_cta": "RSVP",
                "flow_action_payload": {"screen": "QUESTION_ONE"},
            },
        },
    },
}

r = requests.post(url, headers=headers, json=interactive)

print(r.status_code)
print(r.json())
