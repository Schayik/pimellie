import os
import requests

TOKEN = os.getenv("TEMPORARY_ACCESS_TOKEN")
PHONE_ID = os.getenv("PHONE_NUMBER_ID")
ACCOUNT_ID = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID")

url = "https://graph.facebook.com/v17.0/" + PHONE_ID + "/messages"

headers = {
    "Authorization": "Bearer " + TOKEN,
    "Content-Type": "application/json",
}

phone_number = "+31683488976"
test_phone_number = "164031540124222"

body = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "template",
    "template": {"name": "hello_world", "language": {"code": "en_US"}},
}

r = requests.post(url, headers=headers, json=body)

print(r.status_code)
print(r.json())
