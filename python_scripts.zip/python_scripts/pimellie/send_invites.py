import os
import requests

TOKEN = os.getenv("TEMPORARY_ACCESS_TOKEN")
PHONE_ID = os.getenv("PHONE_NUMBER_ID")
ACCOUNT_ID = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID")

url = "https://graph.facebook.com/v17.0/" + PHONE_ID + "/messages"

headers = {
    "Authorization": "Bearer " + TOKEN,
    "Content-Type": "application/json",
}

phone_number = "+31683488976"
phone_number_ellie = "+353838559455"
phone_number_shaun = "+353876459793"

# names = "Floor & Bart"

body = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "text",
    "text": {
        "body": "Hi, we would like to invite you to our wedding on 12 July 2024 in West Cork",
    },
}

invitation_data = {
    "messaging_product": "whatsapp",
    "to": phone_number_shaun,
    "type": "template",
    "template": {
        "name": "invitation",
        "language": {"code": "en_GB"},
        "components": [
            {
                "type": "body",
                "parameters": [{"type": "text", "text": "Floor & Bart"}],
            }
        ],
    },
}

r = requests.post(url, headers=headers, json=invitation_data)

print(r.status_code)
print(r.json())
