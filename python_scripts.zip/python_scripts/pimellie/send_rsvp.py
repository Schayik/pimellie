import os
import requests

TOKEN = os.getenv("TEMPORARY_ACCESS_TOKEN")
PHONE_ID = os.getenv("PHONE_NUMBER_ID")
ACCOUNT_ID = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID")

url = "https://graph.facebook.com/v17.0/" + PHONE_ID + "/messages"

headers = {
    "Authorization": "Bearer " + TOKEN,
    "Content-Type": "application/json",
}

phone_number = "+31683488976"
test_phone_number = "164031540124222"

body = {
    "messaging_product": "whatsapp",
    "to": phone_number,
    "type": "interactive",
    "interactive": {
        "type": "flow",
        "header": {
            "type": "text",
            "text": "RSVP",
        },
        "body": {
            "text": "We would like some information of you",
        },
        "footer": {
            "text": "Press button below to open the form",
        },
        "action": {
            "name": "flow",
            "parameters": {
                "flow_message_version": 3,
                "flow_token": ACCOUNT_ID,
                "flow_id": "371416368682442",
                "flow_cta": "RSVP",
                "flow_action_payload": {"screen": "SIGN_UP"},
            },
        },
    },
}

r = requests.post(url, headers=headers, json=body)

print(r.status_code)
print(r.json())
