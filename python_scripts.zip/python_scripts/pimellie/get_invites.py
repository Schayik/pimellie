import os
import requests

TOKEN = os.getenv("TEMPORARY_ACCESS_TOKEN")
PHONE_ID = os.getenv("PHONE_NUMBER_ID")
ACCOUNT_ID = os.getenv("WHATSAPP_BUSINESS_ACCOUNT_ID")

base_url = "https://graph.facebook.com/v17.0/" + PHONE_ID + "/messages/"
full_url = base_url + "wamid.HBgLMzE2ODM0ODg5NzYVAgARGBIxQzY1NUE0MDRCQzg2OUY0MTAA"

headers = {
    "Authorization": "Bearer " + TOKEN,
    "Content-Type": "application/json",
}

r = requests.get(full_url, headers=headers)

print(r.status_code)
print(r.json())
